void main()
{
	int Main;
	int *p = &Main;

	*p = 5;
}
